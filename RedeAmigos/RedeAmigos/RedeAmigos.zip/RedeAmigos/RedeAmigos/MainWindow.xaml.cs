﻿using RedeAmigos;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Amigo> migs = new List<Amigo>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Cadastro_Click(object sender, RoutedEventArgs e)
        {
            
            if (!string.IsNullOrWhiteSpace(apelido.Text) &&
            !string.IsNullOrWhiteSpace(email.Text) &&
            !string.IsNullOrWhiteSpace(numero.Text))
            {   
                Amigo a = new Amigo();
                a.Apelido = apelido.Text;
                a.Email = email.Text;
                a.Numero = numero.Text;
                migs.Add(a);
                apelido.Text = "";
                email.Text = "";
                numero.Text = "";
            }
           


        }
        private void Busca_Click(object sender, RoutedEventArgs e)
        {
            lista.Text = "";
            string a = apelido.Text;
            string em = email.Text;
            string n = numero.Text;
            

            for (int i = 0; i < migs.Count; i++)
            {
                if (a == migs[i].Apelido && em == migs[i].Email && n == migs[i].Numero)
                {
                    lista.Text= $"Apelido: {migs[i].Apelido} | " +
                           $"Email: {migs[i].Email} | " +
                           $"Número: {migs[i].Numero}";
                    apelido.Text = "";
                    email.Text = "";
                    numero.Text = "";
                    return;
                  }
            }
           

        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
           string a=apelido.Text;
           string em=email.Text;
           string n=numero.Text;

            for(int i=0; i < migs.Count; i++)
            {
              if(a==migs[i].Apelido && em == migs[i].Email && n == migs[i].Numero)
                {
                    migs.RemoveAt(i);
                    MessageBox.Show("Usuário removido com sucesso!");
                     apelido.Text = "";
                     email.Text = "";
                     numero.Text = "";
                     return;
                }
            }
            apelido.Text = "";
            email.Text = "";
            numero.Text = "";

        }

        private void listar_Click(object sender, RoutedEventArgs e)
        {
            if (migs.Count == 0)
            {
                lista.Text = "Você não tem amigos.";
                return;
            }

            
            lista.Text = "";

            
            foreach (var amigo in migs)
            {
                lista.Text += $"Apelido: {amigo.Apelido} | Email: {amigo.Email} | Número: {amigo.Numero}\n";
            }
        }

       
    }
}