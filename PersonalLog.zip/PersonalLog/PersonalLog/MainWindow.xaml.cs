﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PersonalLog
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void esqueci_Click(object sender, RoutedEventArgs e)
        {
            Recuperacao rec=new Recuperacao();
            rec.Show();
            this.Close();
        }

        private void entrar_Click(object sender, RoutedEventArgs e)
        {
            Opcoes op = new Opcoes();
            op.Show();
            this.Close();
        }

        private void registrar_Click(object sender, RoutedEventArgs e)
        {
            Registro reg = new Registro();
            reg.Show();
            this.Close();
        }
    }
}