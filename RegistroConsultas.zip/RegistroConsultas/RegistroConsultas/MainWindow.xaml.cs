﻿using RegistroConsultas;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RegistroConsultas
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { 
        List<Cliente> clientes = new List<Cliente>();
        


public MainWindow()
        {
            InitializeComponent();
        clientes.Add(new Cliente { Id = 1, Nome = "João Silva", TipoCon = "Consulta preventiva", ConteudoCon = "Avaliação de pressão arterial" });
        clientes.Add(new Cliente { Id = 2, Nome = "Maria Souza", TipoCon = "Consulta diagnóstica", ConteudoCon = "Resultado de exames laboratoriais" });
        clientes.Add(new Cliente { Id = 3, Nome = "Carlos Pereira", TipoCon = "Consulta de acompanhamento", ConteudoCon = "Revisão de sintomas" });
        clientes.Add(new Cliente { Id = 4, Nome = "Ana Lima", TipoCon = "Consulta de urgência/emergência", ConteudoCon = "Dor intensa abdominal" });
        clientes.Add(new Cliente { Id = 5, Nome = "Pedro Santos", TipoCon = "Consulta diagnóstica", ConteudoCon = "Acompanhamento pós-cirurgia" });
        clientes.Add(new Cliente { Id = 6, Nome = "Luciana Costa", TipoCon = "Consulta diagnóstica", ConteudoCon = "Orientação sobre dieta" });
        clientes.Add(new Cliente { Id = 7, Nome = "Felipe Rocha", TipoCon = "Consulta preventiva", ConteudoCon = "Check-up anual" });
        clientes.Add(new Cliente { Id = 8, Nome = "Carla Dias", TipoCon = "Consulta diagnóstica", ConteudoCon = "Exame de sangue" });
        }

       

        private void Listar_Click(object sender, RoutedEventArgs e)
        {
            if (clientes.Count == 0)
            {
                id.Text = "Não há clientes cadastrados.";
                return;
            }
            id.Text = "";
            nome.Text = "";

            foreach (var c in clientes)
            {
                id.Text += $" {c.Id}\n";
                nome.Text += $"{c.Nome}\n";
            }



        }

        private void Cancelar_Click(object sender, RoutedEventArgs e)
        {
            id.Text = "";
            nome.Text = "";
        }

        private void Selecionar_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(id.Text) && string.IsNullOrWhiteSpace(nome.Text))
            {
                MessageBox.Show($"Nenhum cliente selecionado!");
            }
            else
            {
                MessageBox.Show($"Cliente selecionado!");
            }
        }

        private void Pesquisar_Click(object sender, RoutedEventArgs e)
        {
            if (Tipo.SelectedItem is ComboBoxItem item)
            {
                string texto = item.Content.ToString();


                id.Text = "";
                nome.Text = "";
                foreach (var c in clientes)
                {
                    if (c.TipoCon == texto)
                    {
                        id.Text += $" {c.Id}\n";
                        nome.Text += $"{c.Nome}\n";
                    }
                }
            }
        }
    }
}